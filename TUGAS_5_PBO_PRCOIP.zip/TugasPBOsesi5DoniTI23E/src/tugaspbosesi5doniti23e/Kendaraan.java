/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tugaspbosesi5doniti23e;

/**
 *
 * @author KOMPUTER JARKOM 25
 */
public class Kendaraan {
    String namapemilik; 
    String nomorplat; 
    String jeniskendaraan;
    private final String namaPemilik;
    private final String nomorPlat;
    private final String jenisKendaraan;

     // Constructor
    public Kendaraan(String namaPemilik, String nomorPlat, String jenisKendaraan) {
        this.namaPemilik = namaPemilik;
        this.nomorPlat = nomorPlat;
        this.jenisKendaraan = jenisKendaraan;
    }
    
    // Method tampilkanInfo
    public void tampilkanInfo() {
        System.out.println("Nama Pemilik: " + namaPemilik);
        System.out.println("Nomor Plat: " + nomorPlat);
        System.out.println("Jenis Kendaraan: " + jenisKendaraan);
    }
    
    // Overloading Method serviceKendaraan
    public void serviceKendaraan() {
        System.out.println("Servis kendaraan sedang dilakukan.");
    }
    
    public void serviceKendaraan(String jenisServis) {
        System.out.println("Servis jenis " + jenisServis + " sedang dilakukan.");
    }
}

