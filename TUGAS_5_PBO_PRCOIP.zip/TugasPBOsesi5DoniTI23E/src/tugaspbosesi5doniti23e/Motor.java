/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugaspbosesi5doniti23e;

/**
 *
 * @author KOMPUTER JARKOM 25
 */
public class Motor extends Kendaraan {
    boolean memilikiBox;
    
    public Motor(String namaPemilik, String nomorPlat, boolean memilikiBox) {
        super("GILANG", "F 1456 AB", "Motor");
        this.memilikiBox = memilikiBox;
    }
    
    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Memiliki Box: " + (memilikiBox ? "Ya" : "Tidak"));
    }

    public void setMemilikiBox(boolean memilikiBox) {
        this.memilikiBox = memilikiBox;
    }

    public boolean isMemilikiBox() {
        return memilikiBox;
    }
}
