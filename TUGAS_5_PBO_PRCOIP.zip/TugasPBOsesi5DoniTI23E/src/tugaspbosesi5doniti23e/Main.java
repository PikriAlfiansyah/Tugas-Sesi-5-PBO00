/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugaspbosesi5doniti23e;

/**
 *
 * @author KOMPUTER JARKOM 25
 */
public class Main {
    
    public static void main(String[] args) {
        // Membuat objek Mobil
        Mobil mobil1 = new Mobil("GILANG", "F 1456 AB", 4);
        mobil1.tampilkanInfo();
        mobil1.serviceKendaraan();
        mobil1.serviceKendaraan("Ganti Oli");
        
        System.out.println();
        
        // Membuat objek Motor
        Motor motor1 = new Motor("DONI", "F 1407 DM", true);
        motor1.tampilkanInfo();
        motor1.serviceKendaraan();
        motor1.serviceKendaraan("Tune Up");
    }
}

