/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugaspbosesi5doniti23e;

/**
 *
 * @author KOMPUTER JARKOM 25
 */
public class Mobil extends Kendaraan {
    int jumlahPintu;
    
    public Mobil(String namaPemilik, String nomorPlat, int jumlahPintu) {
        super("DONI", "F 1407 DM", "Mobil");
        this.jumlahPintu = jumlahPintu;
    }
  
    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Jumlah Pintu: " + jumlahPintu);
    }
    
    public void setJumlahPintu(int jumlahPintu) {
        this.jumlahPintu = jumlahPintu;
    }
    
     public int getJumlahPintu() {
        return jumlahPintu;
    }
}


